import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../models/transaction.dart';
import 'add_expense_page.dart';
import 'select_amount_page.dart';
import 'select_date_page.dart';

class AddIncomePage extends StatefulWidget {
  final String preSelectedCategory;

  const AddIncomePage({
    super.key,
    this.preSelectedCategory = 'FOOD',
  });

  @override
  State<AddIncomePage> createState() => _AddIncomePageState();
}

class _AddIncomePageState extends State<AddIncomePage> {
  late DateTime selectedDate;
  late String selectedCategory;
  double amount = 0.0;
  String currency = 'THB';

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now();
    selectedCategory = widget.preSelectedCategory;
  }

  String _formatDate(DateTime d) {
    const months = [
      '', 'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return '${d.day} ${months[d.month]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgGray,
      appBar: AppBar(
        backgroundColor: AppColors.teal,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Add Transaction',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Toggle income / expense
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {},
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.teal,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Center(
                        child: Text(
                          'ADD INCOME +',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AddExpensePage(
                            preSelectedCategory: selectedCategory,
                          ),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.pink,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Center(
                        child: Text(
                          'ADD EXPENSE -',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Date field
            _buildField(
              icon: Icons.calendar_today_outlined,
              iconColor: AppColors.teal,
              label: 'Select Date',
              value: _formatDate(selectedDate),
              onTap: () async {
                final picked = await Navigator.push<DateTime>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SelectDatePage(initialDate: selectedDate),
                  ),
                );
                if (picked != null) setState(() => selectedDate = picked);
              },
            ),
            const SizedBox(height: 16),

            // Category field
            _buildField(
              icon: Icons.grid_view_rounded,
              iconColor: AppColors.yellow,
              label: 'Select Category',
              value: selectedCategory,
              hasDropdown: true,
              onTap: () async {
                final result = await _showCategoryPicker(context);
                if (result != null) setState(() => selectedCategory = result);
              },
            ),
            const SizedBox(height: 16),

            // Amount field
            GestureDetector(
              onTap: () async {
                final result = await Navigator.push<double>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SelectAmountPage(initialAmount: amount),
                  ),
                );
                if (result != null) setState(() => amount = result);
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    const Icon(Icons.attach_money,
                        color: AppColors.incomeGreen, size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'select Amount',
                            style: TextStyle(
                                fontSize: 11, color: AppColors.mediumGray),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Text(
                                '+ ${amount.toStringAsFixed(2)}',
                                style: const TextStyle(
                                    fontSize: 14, color: AppColors.darkGray),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.lightGray,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Row(
                                  children: [
                                    const Text('🇹🇭',
                                        style: TextStyle(fontSize: 12)),
                                    const SizedBox(width: 4),
                                    Text(
                                      currency,
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: AppColors.darkGray),
                                    ),
                                    const Icon(Icons.arrow_drop_down,
                                        size: 16),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const Spacer(),

            // Save button
            GestureDetector(
              onTap: () {
                final t = Transaction(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  type: 'income',
                  category: selectedCategory,
                  amount: amount,
                  date: selectedDate,
                  currency: currency,
                );
                AppState().addTransaction(t);
                Navigator.pop(context);
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Center(
                  child: Text(
                    'SAVE',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.darkGray,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    bool hasDropdown = false,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: iconColor, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.mediumGray)),
                  const SizedBox(height: 2),
                  Text(value,
                      style: const TextStyle(
                          fontSize: 14, color: AppColors.darkGray)),
                ],
              ),
            ),
            Icon(
              hasDropdown ? Icons.arrow_drop_down : Icons.calendar_today,
              color: AppColors.mediumGray,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _showCategoryPicker(BuildContext context) {
    final cats = [
      'FOOD', 'TRANSPORT', 'SHOPPING', 'COFFEE',
      'CLOTHES', 'GAMES', 'HEALTH', 'BILLS', 'HOUSING'
    ];
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Select Category'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: cats.map((c) => ListTile(
              title: Text(c),
              trailing: c == selectedCategory
                  ? const Icon(Icons.check, color: AppColors.teal)
                  : null,
              onTap: () => Navigator.pop(context, c),
            )).toList(),
          ),
        ),
      ),
    );
  }
}